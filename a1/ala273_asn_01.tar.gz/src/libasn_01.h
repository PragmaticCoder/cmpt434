/**
 * Name: Alvi Akbar
 * NSID: ala273
 * Student Number: 11118887
 */

#ifndef __libasn_01_h__
#define __libasn_01_h__

#include <ctype.h>
#include <stdio.h>

void
split_into_words(char* str, char** words);

void
append(char* s, char c);

#endif