/**
 * Name: Alvi Akbar
 * NSID: ala273
 * Student Number: 11118887
 */

#ifndef __commandline_h__
#define __commandline_h__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Command_interface(int argc, char *argv[], char *retBuffer);

#endif
